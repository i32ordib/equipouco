#include"agenda.hpp"
#include"controlAgenda.hpp"
#include<iostream>
#include<stdio.h>
#include<string>
using namespace std;
main()
{
	int t,dni,tel;
	string c,c2,nom,ap;
	Persona a("Ejemplo","muestra prueba",5,5);
	Agenda b(a);

	while(t!=10)
	{

		cout<<"++++++++++++++++++++++++++++++++++++++++++++++\n";
		cout<<"\t-0. Insertar un nuevo cliente\n";
		cout<<"\t-1. Introducir lista de clientes en fichero\n";
		cout<<"\t-2. Leer lista de clientes del fichero\n";
		cout<<"\t-3. Mostrar agenda\n";
		cout<<"\t-4. Buscar cliente por nombre\n";
		cout<<"\t-5. Buscar cliente por apellidos\n";
		cout<<"\t-6. Eliminar cliente\n";
		cout<<"\t-7. Modificar cliente\n";
		cout<<"\t-10. Salir\n";
		cout<<"+++++++++++++++++++++++++++++++++++++++++++++\n";
		cin>>t;
		switch(t)
		{
			case 0:
				getchar();
				cout<<"dame el nombre\n";
				getline(std::cin,nom);
				cout<<"dame el apellido\n";
				cin>>ap;
				cout<<"dame el dni\n";
				cin>>dni;
				cout<<"dame el telefono\n";
				cin>>tel;
				a.setNombre(nom);
				a.setApellidos(ap);
				a.setDNI(dni);
				a.setTelefono(tel);
				b.insertar(a);
		  		break;
			case 1:
				b.introducirFichero();
		 		 break;
			case 2:
				b.capturar();
		 		 break;
			case 3:
				//cout<<"Nombre\tApellido\tDNI\tTelefono:\n";
				b.mostrar();
		 		 break;
			case 4:
				cout<<"dame el nombre\n";
				cin>>c;
				//cout<<"Nombre\tApellido\tDNI\tTelefono:\n";
				b.BuscarNombre(c);
		 		 break;
		 	case 5:
				cout<<"dame el primer apellido\n";
			 	cin>>c;
				cout<<"dame el segundo apellido\n";
			 	cin>>c2;
				b.BuscarApellido(c+" "+c2);
		 		break;
		 	case 6:
				cout<<"dame el dni\n";
				cin>>dni;
				b.Borrar(dni);
		 		break;
		 	case 7:
				cout<<"dame el dni\n";
				cin>>dni;
				b.Modificar(dni);
		 		break;
		 		 
		}
		getchar();
		cout<<"\tPulsa una tecla para continuar.\n";
		getchar();
	}
}

#ifndef _CONTROLAGENDA_HPP_
#define _CONTROLAGENDA_HPP_
#include"agenda.hpp"
#include<list>
using namespace std;
class Agenda
{
	private:
	list<Persona> agenda;
	public:
	Agenda(Persona a)
	{
		agenda.push_back(a); 
	}
	inline void insertar(const Persona &a)
	{
		agenda.push_back(a); 
	}
	inline void borrar(const Persona &a)
	{
		std::list<Persona>::iterator it = agenda.begin();
		while(it != agenda.end())
		{ 
		if(it->getDNI() == a.getDNI())
			it = agenda.erase(it);
		else
		        it++;
		}
	}
	inline list<Persona> getAgenda() const
	{
		return agenda;
	}
	void introducirFichero();
	void capturar();
	void mostrar();
	void BuscarNombre(string nombre);
	void BuscarApellido(string nombre);
	void Borrar(const int &DNI);
	void Modificar(const int &DNI);
};
#endif



#include"agenda.hpp"
#include<iostream>
using namespace std;
void Persona::imprimir()
{
	cout<<"****************************************\n";
	cout<<"Nombre: "<<getNombre()<<"\n";
	cout<<"Apellidos: "<<getApellidos()<<"\n";
	cout<<"DNI: "<<getDNI()<<"\n";
	cout<<"Télefono: "<<getTelefono()<<" \n";
}

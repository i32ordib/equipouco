#ifndef _AGENDA_HPP_
#define _AGENDA_HPP_
#include<string>
using namespace std;
class Persona
{
	private:
		string _nombre;
		string _apellidos;
		int _DNI;
		int _telefono;
	public:
		Persona(string nombre=" ",string apellidos=" ",int DNI=1234566789,int telefono=597246857)
		{
			setNombre(nombre);
			setApellidos(apellidos);
			setDNI(DNI);
			setTelefono(telefono);
		}
		Persona(const Persona &a)
		{
			*this=a;
		}
		inline string getNombre() const
		{
			return _nombre;
		}
		inline string getApellidos() const
		{
			return _apellidos;
		}
		inline int getDNI() const
		{
			return _DNI;
		}
		inline int getTelefono() const
		{
			return _telefono;
		}
		inline void setNombre(const string &nombre)
		{
			_nombre=nombre;
		}
		inline void setApellidos(const string &apellidos)
		{
			_apellidos=apellidos;
		}
		inline void setDNI(const int &DNI)
		{
			_DNI=DNI;
		}
		inline void setTelefono(const int &telefono)
		{
			_telefono=telefono;
		}
		void imprimir();
};
#endif

#include"controlAgenda.hpp"
#include"agenda.hpp"
#include<list>
#include <fstream>
#include<iostream>
#include<string>
using namespace std;
void Agenda::introducirFichero()
{
	ofstream fs("base.txt");
	std::list<Persona>::iterator it = agenda.begin();
	fs<< (agenda.size()-1)<<"\n";
	while(it != agenda.end())
	{
		if(it->getNombre()!="Ejemplo")
		{
			fs<<it->getNombre()<<" ";
			fs<<it->getApellidos()<<" ";
			fs<<it->getDNI()<<" ";
			fs<<it->getTelefono()<<" \n";
		}
		it++;
	}
	fs.close();
}
void Agenda::capturar()
{
	ifstream fs("base.txt");
 	int longitud;
 	Persona h();
	string non,ap, ap2,blanco;
	int dni,tel;
        fs >> longitud;
        for(int i=0;i<longitud;i++)
        {
            	fs>>non;
		fs>>ap;
		fs>>ap2;
		fs>>dni;
		fs>>tel;
		Persona h(non,ap+" "+ap2,dni,tel);

		insertar(h);
        }
        fs.close();
}
void Agenda::mostrar()
{
	std::list<Persona>::iterator it = agenda.begin();
	while(it != agenda.end())
	{ 
		it->imprimir();

		it++;
	}
}
void Agenda::BuscarNombre(string nombre)
{
	int n=0;
	std::list<Persona>::iterator it = agenda.begin();
	while(it != agenda.end())
	{ 
		if(it->getNombre()==nombre)
		{
			n=1;
			it->imprimir();
		}
		it++;
	}
	if(n==0)
	{
		cout<<"no se encontro al cliente\n";
	}
}
void Agenda::BuscarApellido(string nombre)
{
	int n=0;
	std::list<Persona>::iterator it = agenda.begin();
	while(it != agenda.end())
	{ 
		if(it->getApellidos()==nombre)
		{
			n=1;
			it->imprimir();
		}
		it++;
	}
	if(n==0)
	{
		cout<<"no se encontro al cliente\n";
	}
}
void Agenda::Borrar(const int &DNI)
{
	int n;
	std::list<Persona>::iterator it = agenda.begin();
	while(it != agenda.end())
	{ 
		if(it->getDNI()==DNI)
		{
			n=1;
			cout<<"borrando\n";
			agenda.erase(it);
			it=agenda.end();
		}
		else
		{
			it++;
		}
	}
	if(n==0)
	{
		cout<<"no se encontro al cliente\n";
	}
}
void Agenda::Modificar(const int &DNI, Persona p)
{
	string nombre, apellidos;
	int dni, telefono;
	int t=0;
	std::list<Persona>::iterator it = agenda.begin();
	while(it != agenda.end())
	{ 
		if(it->getDNI()==DNI)
		{
			while(t!=10)
			{
				cout<<"+++++++++++++++++++++++++++++++++\n";
				cout<<"\t-0. Modificar nombre\n";
				cout<<"\t-1. Modificar Apellidos\n";
				cout<<"\t-2. Modificar DNI\n";
				cout<<"\t-3. Modificar teléfono\n";
				cout<<"\t-10. Salir\n";
				cout<<"+++++++++++++++++++++++++++++++++\n";
				cin>>t;
				switch(t)
				{
					case 0:
						cout<<"Introduce el nuevo nombre: ";
						cin>>nombre;
						it->setNombre(nombre);
						break;
					case 1:
						cout<<"Introduce los nuevos apellidos: ";
						cin>>apellidos;
						it->setApellidos(apellidos);
						break;
					case 2:
						cout<<"Introduce el nuevo DNI: ";
						cin>>dni;
						it->setDNI(dni);
						break;
					case 3:
						cout<<"Introduce el nuevo teléfono: ";
						cin>>telefono;
						it->setTelefono(telefono);
						break;					
				}
			}
		}
			it++;
		
	}
}
